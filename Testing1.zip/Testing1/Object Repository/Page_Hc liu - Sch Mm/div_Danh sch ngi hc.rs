<?xml version="1.0" encoding="UTF-8"?>
<WebElementEntity>
   <description></description>
   <name>div_Danh sch ngi hc</name>
   <tag></tag>
   <elementGuidId>e113d3d7-3e86-4aa4-8330-cc62bd647b3e</elementGuidId>
   <selectorCollection>
      <entry>
         <key>XPATH</key>
         <value>//app-action/div/div/div[4]</value>
      </entry>
   </selectorCollection>
   <selectorMethod>XPATH</selectorMethod>
   <useRalativeImagePath>false</useRalativeImagePath>
   <webElementProperties>
      <isSelected>true</isSelected>
      <matchCondition>equals</matchCondition>
      <name>tag</name>
      <type>Main</type>
      <value>div</value>
   </webElementProperties>
   <webElementProperties>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>class</name>
      <type>Main</type>
      <value>col-12 pt-2 pl-2 pb-2 border-bottom action</value>
   </webElementProperties>
   <webElementProperties>
      <isSelected>true</isSelected>
      <matchCondition>equals</matchCondition>
      <name>text</name>
      <type>Main</type>
      <value>
       Danh sách người học
    </value>
   </webElementProperties>
   <webElementProperties>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath</name>
      <type>Main</type>
      <value>/html[1]/body[1]/app-root[1]/div[@class=&quot;content-bound&quot;]/div[@class=&quot;container&quot;]/div[@class=&quot;row&quot;]/div[@class=&quot;col-12 main-content fullscreen&quot;]/app-action[1]/div[@class=&quot;row&quot;]/div[@class=&quot;border-right sidebar closed mobile-open&quot;]/div[@class=&quot;col-12 pt-2 pl-2 pb-2 border-bottom action&quot;]</value>
   </webElementProperties>
   <webElementXpaths>
      <isSelected>true</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:position</name>
      <value>//app-action/div/div/div[4]</value>
   </webElementXpaths>
</WebElementEntity>
